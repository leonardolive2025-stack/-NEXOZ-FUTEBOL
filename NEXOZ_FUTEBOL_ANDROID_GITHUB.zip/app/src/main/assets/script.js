'use strict';
// Demonstração offline: dados fictícios, sem resultados reais.
const games = [
  {id:1,league:'Brasileirão • Demonstração',home:'Atlético Verde',away:'União Azul',day:'Hoje',time:'19:00'},
  {id:2,league:'Libertadores • Demonstração',home:'Estrela FC',away:'Real Horizonte',day:'Hoje',time:'21:30'},
  {id:3,league:'Champions • Demonstração',home:'Sporting Norte',away:'Cidade FC',day:'Amanhã',time:'16:00'},
  {id:4,league:'Copa Nacional • Demonstração',home:'Vila Dourada',away:'Aurora FC',day:'Domingo',time:'18:30'}
];
let favorites=[];
try { const saved=JSON.parse(localStorage.getItem('nexoz-favorites')||'[]');favorites=Array.isArray(saved)?saved:[]; }catch(e){favorites=[];}
let filter='all';let page='home';
const gameList=document.getElementById('games');
const search=document.getElementById('search');
const extra=document.getElementById('page-content');
function render(){
 const term=search.value.trim().toLocaleLowerCase('pt-BR');
 const shown=games.filter(g=>(filter!=='today'||g.day==='Hoje')&&(filter!=='favorites'||favorites.includes(g.id))&&`${g.league} ${g.home} ${g.away}`.toLocaleLowerCase('pt-BR').includes(term));
 gameList.replaceChildren();
 if(!shown.length){const p=document.createElement('p');p.className='notice';p.textContent='Nenhuma partida encontrada neste filtro.';gameList.appendChild(p);}
 shown.forEach(g=>{
  const article=document.createElement('article');article.className='game';
  const top=document.createElement('div');top.className='game-top';
  const league=document.createElement('span');league.textContent=g.league;
  const status=document.createElement('span');status.className='status';status.textContent='AGENDADO';top.append(league,status);
  const teams=document.createElement('div');teams.className='teams';teams.textContent=`${g.home}  ×  ${g.away}`;
  const bottom=document.createElement('div');bottom.className='game-bottom';
  const date=document.createElement('span');date.textContent=`📅 ${g.day} • ${g.time} (fictício)`;
  const btn=document.createElement('button');btn.className='fav-btn';btn.textContent=favorites.includes(g.id)?'★ Salvo':'☆ Favoritar';
  btn.addEventListener('click',()=>{favorites=favorites.includes(g.id)?favorites.filter(id=>id!==g.id):[...favorites,g.id];try{localStorage.setItem('nexoz-favorites',JSON.stringify(favorites));}catch(e){}render();});
  bottom.append(date,btn);article.append(top,teams,bottom);gameList.appendChild(article);
 });
}
function changePage(next){
 page=next;document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('selected',b.dataset.page===next));
 extra.replaceChildren();
 const titles={home:'Partidas',matches:'Todos os jogos',watch:'Onde assistir',favorites:'Meus favoritos'};
 document.getElementById('page-title').textContent=titles[next]||'Partidas';
 filter=next==='favorites'?'favorites':'all';
 document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b.dataset.filter===filter));
 if(next==='watch'){
  const card=document.createElement('div');card.className='info';
  const h=document.createElement('h3');h.textContent='📺 Transmissões oficiais';
  const p=document.createElement('p');p.textContent='Em breve: informações sobre onde assistir a partidas reais em serviços e canais autorizados. Este protótipo não reproduz vídeos nem disponibiliza links não licenciados.';
  card.append(h,p);extra.appendChild(card);
 }
 document.querySelector('.filters').hidden=next==='watch';
 document.querySelector('.search-label').hidden=next==='watch';search.hidden=next==='watch';
 document.querySelector('.notice').hidden=next==='watch';gameList.hidden=next==='watch';
 render();
}
document.querySelectorAll('.filter').forEach(btn=>btn.addEventListener('click',()=>{filter=btn.dataset.filter;document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b===btn));render();}));
document.querySelectorAll('.nav-item').forEach(btn=>btn.addEventListener('click',()=>changePage(btn.dataset.page)));
search.addEventListener('input',render);
changePage('home');
